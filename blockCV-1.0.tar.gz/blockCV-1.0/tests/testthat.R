library(testthat)
library(blockCV)

test_check("blockCV")
